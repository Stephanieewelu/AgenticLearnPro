# Agentic AI Package
# A simple agentic AI package using reinforcement learning

__version__ = "0.1.0"